/*
 *  MCIP -- Management and Control Information Protocol
 *
 *  Copyright (C) 2012 INSYS Microelectronics GmbH <support@insys-tec.de>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License version 2
 *  as published by the Free Software Foundation.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (see the file COPYING included with this
 *  distribution); if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#include "libmcip.h"

int main(int argc, char *argv[])
{
    int fd = -1;
    struct oid_list *my_oids = NULL; 
 
    printf("MCIP Example: register\n");   

    /* init my OIDs */
    mcip_oid_append(&my_oids, 1);
    mcip_oid_append(&my_oids, 2);
    mcip_oid_append(&my_oids, 8);
    mcip_oid_append(&my_oids, 999);
    mcip_oid_append(&my_oids, 255);
    mcip_oid_append(&my_oids, 256);
    mcip_oid_append(&my_oids, 65532);
    /* ... */

    /* register */
    fd = mcip_uds_register(MCIP_DEFAULT_UDS, my_oids);
    if(fd == -1) {
        printf("ERROR: register failed\n");  
        mcip_oids_destroy(my_oids);
        return -1;
    }

    /* deregister */
    mcip_uds_deregister(&fd);

    /* free oid list */
    mcip_oids_destroy(my_oids);

    printf("EXIT\n"); 
    return 0;
}
