/*
 *  MCIP -- Management and Control Information Protocol
 *
 *  Copyright (C) 2012 INSYS Microelectronics GmbH <support@insys-tec.de>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License version 2
 *  as published by the Free Software Foundation.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (see the file COPYING included with this
 *  distribution); if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/* contains helpers and utils for MCIP itself */

#include "../../include/mcip.h"

/* print a log entry into the log file */
void log_entry(char *text, ...)
{
    char buffer[MCIP_MAX_TEXT_LENGTH + 1];
    va_list argpointer;

    /* log to syslog, if there is no explicit log file */
    if(config.log_file == NULL) {
        va_start(argpointer, text);
        vsprintf(buffer, text, argpointer);
        va_end(argpointer);

        openlog("mcip", LOG_PID | LOG_NDELAY, LOG_DAEMON);
        syslog(LOG_INFO, "%s", buffer);
        closelog();

        return;
    }
    else {
        time_t now = 0;
        struct tm *p_now_tm;
        FILE *tmp = NULL;

        tmp = fopen(config.log_file, "a");
        if(tmp == NULL)
            return;

        /* get current time */
        time(&now);
        p_now_tm = localtime(&now);
        strftime(buffer, sizeof(buffer), "%e %b %Y %H:%M:%S", p_now_tm);
        fprintf(tmp, "%s ", buffer);
        va_start(argpointer, text);
        vfprintf(tmp, text, argpointer);
        va_end(argpointer);
        fprintf(tmp, "\n");
        fclose(tmp);
    }

    return;
}

/* daemonize this process; return 1 if everything is OK */
int daemonize(void)
{
    int pid_t, nullfd;

    if((pid_t = fork()) < 0)
        exit(0);
    else if(pid_t != 0)
        exit(0);

    setsid();

    /* change working directory to root so we won't prevent file systems from being unmounted */
    if(chdir("/") < 0)
        exit(0);

    /* attach file descriptors 0, 1, and 2 to /dev/null */
    nullfd = open("/dev/null", O_RDWR);
    if(dup2(nullfd, 0) == -1)
        exit(1);
    if(dup2(nullfd, 1) == -1)
        exit(1);
    if(dup2(nullfd, 2) == -1)
        exit(1);

    return 1;
}

/* close file descriptor and set int to -1 */
void close_fd(int *fd)
{
    int fd_here;

    fd_here = *fd;
    if(*fd != -1) {
        close(fd_here);
        *fd = -1;
    }
    return;
}

/* free wrapper function to avoid dangling pointers */
void safefree(void **pp)
{
    if(pp != NULL && *pp != NULL) {
        free(*pp);
        *pp = NULL;
    }
    return;
}

/* return a uint16_t value from two sequently bytes */
uint16_t value_of(uint8_t *start_byte)
{
    if(start_byte == NULL || start_byte + 1 == NULL)
        return 0;

    if(sizeof(start_byte) < 2)
        return 0;

    return *start_byte | (*(start_byte + 1) << 8);
}

/* check if single thread daemon is already running */
int already_running(char *pid_file)
{
    int fd;
    char buf[16];
    struct flock fl;

    if(pid_file != NULL)
        fd = open(pid_file, O_RDWR | O_CREAT, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
    else
        fd = open(MCIP_DEFAULT_PID, O_RDWR | O_CREAT, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);

    if(fd < 0) {
        printf("Could not create PID file\n");
        return 1;
    }

    /* file already locked */
    fl.l_type = F_WRLCK;
    fl.l_start = 0;
    fl.l_whence = SEEK_SET;
    fl.l_len = 0;
    if(fcntl(fd, F_SETLK, &fl) < 0) {
        if(errno == EACCES || errno == EAGAIN) {
            close(fd);
            return 1;
        }
        return 1;
    }

    /* truncate file to length 0 */
    if(ftruncate(fd, 0))
        return 1;

    sprintf(buf, "%ld", (long) getpid());
    if(write(fd, buf, strlen(buf) + 1) < 0)
        return 1;

    return 0;
}
