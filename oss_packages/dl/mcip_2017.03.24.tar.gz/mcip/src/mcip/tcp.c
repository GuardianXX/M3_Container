/*
 *  MCIP -- Management and Control Information Protocol
 *
 *  Copyright (C) 2012 INSYS Microelectronics GmbH <support@insys-tec.de>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License version 2
 *  as published by the Free Software Foundation.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (see the file COPYING included with this
 *  distribution); if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/* contains code for communication with MCIP via TCP */

#include "../../include/mcip.h"

/* open the TCP listener */
int open_TCP_listener(void)
{
    int yes = 1;
    struct addrinfo hints, *ai;
    char port[6];

    memset(&hints, 0, sizeof hints);
    hints.ai_family = PF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;

    /* get the address infos for the listener */
    sprintf(port, "%d", config.TCP_listen_port);
    if(getaddrinfo(NULL, port, &hints, &ai) != 0) {
        log_entry("Start listening to device drivers failed");
        fd_tcp = -1;
        return 1;
    }

    /* establish listen socket */
    fd_tcp = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
    if(fd_tcp < 0) {
        log_entry("Creation of TCP listen socket failed: %s", strerror(errno));
        fd_tcp = -1;
        return 1;
    }

    /* configure socket options */
    setsockopt(fd_tcp, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int));

    if (config.tcp_bind != NULL) { /* bind to specific interface if configured */
        if ((setsockopt(fd_tcp, SOL_SOCKET, SO_BINDTODEVICE, config.tcp_bind, strlen(config.tcp_bind))) == -1) {
            log_entry("SO_BINDTODEVICE failed (%s): %s", config.tcp_bind, strerror(errno));
            close(fd_tcp);
            fd_tcp = -1;
            return 1;
        }
    }

    /* bind to the port */
    if(bind(fd_tcp, ai->ai_addr, ai->ai_addrlen) < 0) {
        log_entry("Binding to TCP listen socket failed: %s", strerror(errno));
        close(fd_tcp);
        fd_tcp = -1;
        return 1;

    }
    freeaddrinfo(ai);

    /* start listening on socket */
    if(listen(fd_tcp, 10) == -1) {
        log_entry("Listening on TCP listen socket failed: %s", strerror(errno));
        close(fd_tcp);
        fd_tcp = -1;
        return 1;
    }

    /* add socket to file descriptor set */
    FD_SET(fd_tcp, &fds_master);
    if(fd_tcp > fd_max)
        fd_max = fd_tcp;

    return 0;
}

/* accept a TCP connection */
int accept_TCP_socket(void)
{
    struct device_driver *dd_new, *walk;
    struct sockaddr_storage client_address;
    socklen_t client_len = sizeof(client_address);

    /* create a new device driver instance */
    dd_new = malloc(sizeof(struct device_driver));
    dd_new->device_type = MCIP_DEVICE_TCP;
    dd_new->flag_only_public = 1; /* only public OIDs are allowed */
    dd_new->write_buffer = NULL;
    dd_new->write_buffer_end = dd_new->write_buffer;
    dd_new->read_buffer = NULL;
    dd_new->read_buffer_end = dd_new->read_buffer;
    dd_new->read_buffer_work = dd_new->read_buffer;
    dd_new->objects = NULL;
    dd_new->state = MCIP_STATE_EMPTY;
    dd_new->next = NULL;

    /* append the new instance */
    if(device_list == NULL)
        device_list = dd_new;
    else {
        /* if there is already a device driver in the list, find the last one */
        for(walk = device_list; walk->next != NULL;  walk = walk->next);
        walk->next = dd_new;
    }

    /* accept incomming connection */
    dd_new->fd = accept(fd_tcp, (struct sockaddr *) &client_address, &client_len);
    if (dd_new->fd  == -1) {
        log_entry("Could not accept on TCP listen socket: %s", strerror(errno));
        dd_new->fd = -1;
        return 1;
    }

    /* add to master set */
    FD_SET(dd_new->fd, &fds_master);
    if(dd_new->fd > fd_max)
        fd_max = dd_new->fd;

    return 0;
}
