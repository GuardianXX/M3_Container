/*
 *  MCIP -- Management and Control Information Protocol
 *
 *  Copyright (C) 2012 INSYS Microelectronics GmbH <support@insys-tec.de>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License version 2
 *  as published by the Free Software Foundation.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (see the file COPYING included with this
 *  distribution); if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "../../include/mcip.h"

fd_set fds_master;      /* file descriptor set with all file descriptors */
fd_set fds_tmp;         /* temporary file descriptor */

int fd_max;             /* file descriptor containing maximal fd of all UDS or TCP connections */
int fd_uds;             /* file descriptor for listening for new drivers to connect */
int fd_tcp;             /* file descriptor for other MCIPs connecting via TCP */

struct device_driver *device_list; /* pointer to the very first device driver, that is connected to this MCIP */

int reread_config_flag; /* flag, to notice main loop from occurance of SIGUSR1 */
int sigterm_flag;       /* flag, to notice main loop from occurance of SIGTERM and SIGINT */

/* signal handler for SIGPIPE */
void sigpipe_handler(int sig)
{
    return;
}

/* signal handler for SIGUSR1 (used to trigger reread of configuration) */
void sigusr1_handler(int sig)
{
    reread_config_flag = 1;
    return;
}

/* signal handler for SIGTERM and also SIGINT */
void sigterm_handler(int sig)
{
    sigterm_flag = 1;
    return;
}

/* never ending main loop */
int main(int argc, char *argv[])
{
    int sel, ret;
    struct timeval tv;
    struct device_driver *walk;

    /* Init values */
    device_list = NULL;
    fd_uds = fd_tcp = -1;
    reread_config_flag = 0;
    sigterm_flag = 0;

    /* get configuration from file */
    if(argc != 2 || argv[1] == NULL) {
        /* user did not appended a config file */
        read_config(MCIP_DEFAULT_CONF);
    }
    else {
        /* user did append a config file */
        if(read_config(argv[1])) {
            printf("Config file %s not found\n", argv[1]);
            return 1;
        }
    }

    if(check_config()) {
        printf("Config file invalid\n");
        return 1;
    }

    /* install signal handler to avoid closing MCIP at sigpipe */
    signal(SIGPIPE, sigpipe_handler);

    /* install signal handler for SIGUSR1, which is used to trigger reread of configuration */
    signal(SIGUSR1, sigusr1_handler);

    /* install singal handler for SIGTERM and SIGINT */
    signal(SIGTERM, sigterm_handler);
    signal(SIGINT, sigterm_handler);

    /* do a fork */
    if(config.fork_to_daemon) {
        if(!daemonize())
            return 0;
    }

    /* ensure that only one mcip is running */
    if(already_running(config.pid_file))
        exit(1);

    log_entry("Management and Control Information Protocol daemon (MCIP daemon) started");

    /* endless main loop */
    while(sigterm_flag == 0) {

        /* reread configuration if signal SIGUSR1 told us */
        if(reread_config_flag) {
            if(argc != 2 || argv[1] == NULL)
                ret = reread_config(MCIP_DEFAULT_CONF);
            else
                ret = reread_config(argv[1]);

            /* if this fails, we terminate */
            if(ret == 1) {
                log_entry("Error during reread of config file");
                break;
            }
            reread_config_flag = 0;
            log_entry("Reread configuration file");
        }

        /* reopen UDS listener for others to connect */
        if(fd_uds == -1) {
            if(open_device_listener()) {
                log_entry("Unable to create UDS for device drivers");
                printf("Unable to create UDS for device drivers\n");
                return 1;
            }
        }

        /* reopen TCP listener for others connect */
        if(config.TCP_listen_port != 0 && fd_tcp == -1) {
            if(open_TCP_listener()) {
                log_entry("Unable to prepare TCP listener for other MCIPs");
                return 1;
            }
        }

        /* check if data is pending on one of our file descriptors */
        FD_ZERO(&fds_tmp);
        fds_tmp = fds_master;
        tv.tv_sec = 10;
        tv.tv_usec = 10000;
        sel = select(fd_max + 1, &fds_tmp, NULL, NULL, &tv);
        if(sel > 0) {
            /* check if someone wants to connect via UDS */
            if(FD_ISSET(fd_uds, &fds_tmp))
                add_device();

            /* check if someone wants to connect via TCP */
            if(fd_tcp != -1 && FD_ISSET(fd_tcp, &fds_tmp))
                accept_TCP_socket();

            /* check if someone sent data to MCIP */
            for(walk = device_list; walk != NULL; walk = walk->next) {
                /* if the file descriptor is 0, the device is dead */
                if(walk->fd < 1) {
                    remove_device(walk);
                    /* do not continue after a device has been removed to save trouble */
                    break;
                }

                /* read all data a device driver may has sent */
                if(FD_ISSET(walk->fd, &fds_tmp)) {
                    if(read_device(walk)) {
                        /* device driver seems to be dead, remove it. */
                        remove_device(walk);
                        /* do not continue after a device has been removed to save trouble */
                        break;
                    }
                }
            }

            /* check if a valid telegram is in a buffer, so it can be sent to the target */
            check_read_buffers();

            /* check if there is data left to send */
            // Todo nothing to do yet
            // check_write_buffers();
        }
        /* if a SIGUSR1 is sent to the programm, select will fail with EINTR */
        else if(sel == -1 && errno != EINTR) {
            log_entry("Error select: %s", strerror(errno));
            return 1;
        }
    }

    /* clean up all connected device drivers */
    for(; device_list != NULL; )
        remove_device(device_list);

    if(config.pid_file != NULL)
        unlink(config.pid_file);

    /* clean up the tcp and uds listener */
    if(fd_tcp != -1)
        close(fd_tcp);
    if(fd_uds != -1) {
        close(fd_uds);
        unlink(config.uds_file);
    }

    safefree((void **)&config.log_file);
    safefree((void **)&config.pid_file);
    safefree((void **)&config.uds_file);

    return 0;
}
