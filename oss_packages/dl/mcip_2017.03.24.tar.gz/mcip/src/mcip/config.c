/*
 *  MCIP -- Management and Control Information Protocol
 *
 *  Copyright (C) 2012 INSYS Microelectronics GmbH <support@insys-tec.de>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License version 2
 *  as published by the Free Software Foundation.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (see the file COPYING included with this
 *  distribution); if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/* contains helpers and utils for MCIP itself */

#include "../../include/mcip.h"

struct mcip_config config;

/* extract string parameter from config file */
static void get_config_string_value(char *p, char **config_string)
{
    int i;
    char buffer[MCIP_MAX_TEXT_LENGTH + 1];

    for(i = 0; i < MCIP_MAX_TEXT_LENGTH && *p != ' ' && *p != '#' && *p != '\n' && *p != '\r'; i++, p++)
        buffer[i] = *p;
    buffer[i] = '\0';

    *config_string = malloc(strlen(buffer) + 1);
    if(*config_string != NULL) {
        strcpy(*config_string, buffer);
    }

    return;
}

/* check, whether all required configuration is provided */
int check_config(void)
{
    /* set default values in case, the config in config.file is incomplete */
    if(config.pid_file == NULL) {
        config.pid_file = malloc(strlen(MCIP_DEFAULT_PID) + 1);
        strcpy(config.pid_file, MCIP_DEFAULT_PID);
    }

    if(config.uds_file == NULL) {
        config.uds_file = malloc(strlen(MCIP_DEFAULT_UDS) + 1);
        strcpy(config.uds_file, MCIP_DEFAULT_UDS);
    }

    return 0;
}

/* read configuration of MCIP from file */
int read_config(char *config_file)
{
    FILE *tmp;
    char *p;
    char text_line[MCIP_MAX_TEXT_LENGTH + 1];
    int tcp_listen = 0;

    memset(&config, 0x00, sizeof(struct mcip_config));

    tmp = fopen(config_file, "r");
    if(tmp == NULL) {
        log_entry("Could not open config file");
        return 1;
    }

    /* preinit some values */
    fd_tcp = -1;
    config.fork_to_daemon = 0;
    config.TCP_listen_port = 0;

    for(; fgets(text_line, MCIP_MAX_TEXT_LENGTH, tmp);) {
        /* ignore comments */
        if(text_line[0] == '#')
            ;
        /* should MCIP fork? */
        else if(strstr(text_line, "daemon=1"))
            config.fork_to_daemon = 1;
        /* path for MCIP log file */
        else if(strstr(text_line, "LOG=")) {
            p = index(text_line, (int) '=');
            get_config_string_value(++p, &config.log_file);
        }
        /* path for MCIP PID file */
        else if(strstr(text_line, "PID=")) {
            p = index(text_line, (int) '=');
            get_config_string_value(++p, &config.pid_file);
        }
        /* path for UDS socket file for MCIP to listen on */
        else if(strstr(text_line, "UDS=")) {
            p = index(text_line, (int) '=');
            get_config_string_value(++p, &config.uds_file);
        }
        /* enable incoming TCP connections */
        else if(strstr(text_line, "TCP_listen=")) {
            p = index(text_line, (int) '=');
            p++;
            tcp_listen = *p;
        }
        /* listen on this port for incoming TCP connections */
        else if(strstr(text_line, "TCP_port=")) {
            p = index(text_line, (int) '=');
            p++;
            config.TCP_listen_port = atoi(p);
        }
        /* bind TCP server to network device */
        else if(strstr(text_line, "TCP_bind=")) {
            p = index(text_line, (int) '=');
            get_config_string_value(++p, &config.tcp_bind);
            if((config.tcp_bind != NULL) && (strcmp(config.tcp_bind, "all") == 0)) {
                /* tcp_bind=all equals tcp_bind=  , listen on all interfaces
                 * the rest of this sw is working with 'all' if config.tcp_bind == NULL */
                safefree((void **)&config.tcp_bind);
            }
        }
    }
    fclose(tmp);

    if(tcp_listen != '1' || config.TCP_listen_port < 1 || config.TCP_listen_port > 65535)
        config.TCP_listen_port = 0;

    return 0;
}


/* reread the configuration file for changed tcp settings */
int reread_config(char *config_file)
{
    FILE *tmp;
    char *p, *tcp_bind_old = NULL;
    char text_line[MCIP_MAX_TEXT_LENGTH + 1];
    int tcp_listen = 0, TCP_listen_old;

    tmp = fopen(config_file, "r");
    if(tmp == NULL) {
        log_entry("Could not open config file");
        return 1;
    }

    /* remember the old value of the TCP listen port and TCP bind interface */
    TCP_listen_old = config.TCP_listen_port;
    if (config.tcp_bind != NULL) {
        tcp_bind_old = malloc(strlen(config.tcp_bind) + 1);
        if (tcp_bind_old != NULL) {
            strcpy(tcp_bind_old, config.tcp_bind);
            tcp_bind_old[strlen(tcp_bind_old)] = '\0';
        }
    }

    for(; fgets(text_line, MCIP_MAX_TEXT_LENGTH, tmp);) {
        /* ignore comments */
        if(text_line[0] == '#')
            ;
        /* enable incoming TCP connections */
        else if(strstr(text_line, "TCP_listen=")) {
            p = index(text_line, (int) '=');
            p++;
            tcp_listen = *p;
        }
        /* listen on this port for incoming TCP connections */
        else if(strstr(text_line, "TCP_port=")) {
            p = index(text_line, (int) '=');
            p++;
            config.TCP_listen_port = atoi(p);
        }
        /* bind TCP server to network device */
        else if(strstr(text_line, "TCP_bind=")) {
            p = index(text_line, (int) '=');
            if (config.tcp_bind != NULL)
                free(config.tcp_bind);
            get_config_string_value(++p, &config.tcp_bind);
            if((config.tcp_bind != NULL) && (strcmp(config.tcp_bind, "all") == 0)) {
                /* tcp_bind=all equals tcp_bind=  , listen on all interfaces
                 * the rest of this sw is working with 'all' if config.tcp_bind == NULL */
                safefree((void **)&config.tcp_bind);
            }
        }
    }
    fclose(tmp);

    if(tcp_listen != '1' || config.TCP_listen_port < 1 || config.TCP_listen_port > 65535)
        config.TCP_listen_port = 0;

    /* if the tcp listen port or tcp bind device changed */
    if((config.TCP_listen_port != TCP_listen_old) ||
        (tcp_bind_old == NULL && config.tcp_bind != NULL) || /* tcp_bind was activated */
        (tcp_bind_old != NULL && config.tcp_bind == NULL) || /* tcp bind was deactivated */
        ((tcp_bind_old != NULL && config.tcp_bind != NULL) &&
        (0 != strcmp(config.tcp_bind, tcp_bind_old)))) {      /* tcp bind device changed */
        /* close the listen file descriptor */
        if(fd_tcp != -1) {
            close(fd_tcp);
            FD_CLR(fd_tcp, &fds_master);
            fd_tcp = -1;
        }

        /* if tcp was disabled, remove all device drivers, that use tcp */
        if(config.TCP_listen_port == 0) {
            if(remove_tcp_devices()) {
                if(tcp_bind_old != NULL)
                    free(tcp_bind_old);
                return 1;
            }
        }
    }

    if(tcp_bind_old != NULL)
        free(tcp_bind_old);

    return 0;
}
