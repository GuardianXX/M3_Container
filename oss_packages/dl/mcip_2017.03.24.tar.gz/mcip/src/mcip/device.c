/*
 *  MCIP -- Management and Control Information Protocol
 *
 *  Copyright (C) 2012 INSYS Microelectronics GmbH <support@insys-tec.de>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License version 2
 *  as published by the Free Software Foundation.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (see the file COPYING included with this
 *  distribution); if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/* contains code to communicate to device drivers via Unix Domain Socket (UDS) */

#include "../../include/mcip.h"

/* open the UDS listener, so device drivers can connect to MCIP */
int open_device_listener(void)
{
    struct sockaddr_un man_address;
    int man_len;

    /* remove old UDS socket file */
    unlink(config.uds_file);

    fd_uds = socket(AF_UNIX, SOCK_STREAM, 0);
    if(fd_uds < 0) {
        log_entry("Start listening to device drivers failed");
        fd_uds = -1;
        return 1;
    }

    memset(&man_address, 0, sizeof(man_address));
    man_address.sun_family = AF_UNIX;
    sprintf(man_address.sun_path, "%s", config.uds_file);
    man_len = strlen(man_address.sun_path) + sizeof(man_address.sun_family);

    /* bind to socket file */
    if(bind(fd_uds, (struct sockaddr *) &man_address, man_len) < 0) {
        close_fd(&fd_uds);
        log_entry("Binding UDS listener failed: %s", strerror(errno));
        return 1;
    }

    /* fix the permission of socket file for allowing connections from clients run by users other than root */
    if(chmod(config.uds_file, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH) < 0) {
        log_entry("Warning: Unable to adjust the permission of socket file (%s): %s", config.uds_file, strerror(errno));
    }

    /* put socket in listen state */
    if(listen(fd_uds, MCIP_UDS_BACKLOG) < 0) {
        close_fd(&fd_uds);
        log_entry("Listening on UDS interface failed: %s", strerror(errno));
        return 1;
    }

    /* add socket to file descriptor set */
    FD_SET(fd_uds, &fds_master);
    if(fd_uds > fd_max)
        fd_max = fd_uds;

    return 0;
}

/* add another device driver to the list */
int add_device(void)
{
    struct device_driver *dd_new, *walk;
    struct sockaddr_un client_address;
    unsigned int client_len;

    memset(&client_address, 0, sizeof(client_address));
    client_address.sun_family = AF_UNIX;
    sprintf(client_address.sun_path, "%s", config.uds_file);
    client_len = strlen(client_address.sun_path) + sizeof(client_address.sun_family);

    /* create a new device driver instance */
    dd_new = malloc(sizeof(struct device_driver));
    dd_new->device_type = MCIP_DEVICE_UDS;
    dd_new->flag_only_public = 0; /* all OIDs are allowed */
    dd_new->write_buffer = NULL;
    dd_new->write_buffer_end = dd_new->write_buffer;
    dd_new->read_buffer = NULL;
    dd_new->read_buffer_end = dd_new->read_buffer;
    dd_new->read_buffer_work = dd_new->read_buffer;
    dd_new->objects = NULL;
    dd_new->state = MCIP_STATE_EMPTY;
    dd_new->next = NULL;

    /* append the new instance */
    if(device_list == NULL)
        device_list = dd_new;
    else {
        /* if there is already a device driver in the list, find the last one */
        for(walk = device_list; walk->next != NULL;  walk = walk->next);
        walk->next = dd_new;
    }

    /* accept incomming connection */
    dd_new->fd = accept(fd_uds, (struct sockaddr *) &client_address, &client_len);
    if(dd_new->fd == -1) {
        log_entry("Accepting device driver failed");
        dd_new->fd = -1;
        return 1;
    }

    /* add to master set */
    FD_SET(dd_new->fd, &fds_master);
    if(dd_new->fd > fd_max)
        fd_max = dd_new->fd;

    return 0;
}

/* remove a device driver from the list */
int remove_device(struct device_driver *dd)
{
    struct device_driver *walk;
    struct object_list *ob_walk, *walknext;
    int found = 0;

    if((!dd) || (!device_list)) {
        log_entry("Defective device driver list");
        return 1;
    }

    /* special case: removing first list element */
    if(dd == device_list) {
        device_list = dd->next;
        found = 1;
    }
    else {
        /* find the list element in front of the one which should be removed */
        for(walk = device_list; walk != NULL; walk = walk->next) {
            if(walk->next == dd) {
                walk->next = dd->next;
                found = 1;
                break;
            }
        }
    }
    if(found == 0)
        return 1;

    /* clear device driver buffers */
    tcdrain(dd->fd);
    close(dd->fd);
    tcflush(dd->fd, TCIOFLUSH);
    FD_CLR(dd->fd, &fds_master);

    /* destroy device driver resources */
    /* follow the trail of objects till the end and free the list elements */
    for(ob_walk = dd->objects; ob_walk != NULL; ) {
        walknext = ob_walk->next;
        free(ob_walk);
        ob_walk = walknext;
    }

    safefree((void **)&dd->read_buffer);
    safefree((void **)&dd->write_buffer);
    safefree((void **)&dd);

    return 0;
}

/* read data from device driver */
int read_device(struct device_driver *dd)
{
    int i = 0;
    int work_offset = 0;
    int new_buffer_size = MCIP_READ_BUFFER; /* read capacity in bytes */
    int old_buffer_size = 0;  /* amount of bytes already read */
    uint8_t *buffer;

    /* calculate size of buffers */
    if(dd->read_buffer == NULL)
        /* a fresh read buffer should start with a small buffer */
        new_buffer_size = MCIP_READ_BUFFER;
    else {
        /* there is already a buffer, expand it to the maximum size */
        old_buffer_size = dd->read_buffer_end - dd->read_buffer;
        new_buffer_size = MCIP_MAX_READ_BUFFER - old_buffer_size;
    }

    /* TODO if new_buffer_size == 0 --> do not go on, do not call read with 0 bytes */
    /* but select already triggered, if we do not read, we do not know, that there is data */

    /* create a big buffer */
    buffer = malloc(new_buffer_size);
    if(buffer == NULL) {
        log_entry("Unable to allocate memory");
        return 1;
    }

    /* read as much data as possible */
    i = read(dd->fd, buffer, new_buffer_size);
    if(i == 0) { /* read return: end of file */
        safefree((void **)&buffer);
        return 1;
    }
    /* read failed */
    else if(i == -1) {
        log_entry("Error read: %s", strerror(errno));
        safefree((void **)&buffer);

        if (errno == EAGAIN || errno == EWOULDBLOCK)
            return 0;
        else
            return 1;
    }
    /* data received */
    else {
        /* there was no data yet, reuse the buffer as new read_buffer */
        if(dd->read_buffer == NULL) {
            dd->read_buffer = realloc(buffer, i);
            dd->read_buffer_work = dd->read_buffer;
            dd->read_buffer_end = dd->read_buffer + i;
        }
        /* there was already data, append it to the existing buffer */
        else {
            /* remember offset to working pointer before reallocating */
            work_offset = dd->read_buffer_work - dd->read_buffer;

            dd->read_buffer = realloc(dd->read_buffer, i + old_buffer_size);
            if(dd->read_buffer == NULL) {
                safefree((void **)&buffer);
                return 1;
            }

            /* append data */
            memcpy(dd->read_buffer + old_buffer_size, buffer, i);
            safefree((void **)&buffer);

            /* set pointers again */
            dd->read_buffer_work = dd->read_buffer + work_offset;
            dd->read_buffer_end = dd->read_buffer + old_buffer_size + i;
        }
    }

    return 0;
}

/* clear a read buffer of a device driver */
int reset_buffer(struct device_driver *dd)
{
    uint8_t *buffer;
    int new_buffer_size = 0;

    if(!dd || !dd->read_buffer_work || !dd->read_buffer_end)
        return 0;

    dd->state = MCIP_STATE_EMPTY;
    if(dd->read_buffer_work == dd->read_buffer_end)
        safefree((void **) &dd->read_buffer);
    else {
        /* find the next start byte in the buffer */
        for(; dd->read_buffer_work < dd->read_buffer_end && *(dd->read_buffer_work) != MCIP_START_BYTE; dd->read_buffer_work++);
        new_buffer_size = dd->read_buffer_end - dd->read_buffer_work;

        /* a new buffer is necessary, because beginning and end of buffer is going to change */
        buffer = malloc(new_buffer_size);
        memcpy(buffer, dd->read_buffer_work, new_buffer_size);
        free(dd->read_buffer);
        dd->read_buffer = buffer;
        dd->read_buffer_end = dd->read_buffer + new_buffer_size;
    }

    dd->read_buffer_work = dd->read_buffer;

    return 0;
}

/* learn all about the drivers capabilities like object IDs */
int learn_capabilities(struct device_driver *dd)
{
    uint16_t i;
    uint8_t *p;
    struct object_list *tmp, *walk = NULL;
    char first_object = 1;

    /* if the payload of the hello telegram is not even, it is defective */
    if(value_of(dd->read_buffer + MCIP_OFFSET_LENGTH) % 2) {
        reset_buffer(dd);
        log_entry("Defective hello telegram of new device driver");
        return 1;
    }

    /* the object value of the hello telegram contains all object IDs of the device driver */
    p = dd->read_buffer + MCIP_OFFSET_HEADER + MCIP_SIZEOF_OBJECT_ID;

    /* skip object ID of this telegram, only object value is interesting */
    i = value_of(dd->read_buffer + MCIP_OFFSET_LENGTH) - 2;

    /* create the objects and fill it with the new data */
    for(; i > 0; i -= 2, p += 2) {
        tmp = malloc(sizeof(struct object_list));
        if(tmp == NULL) {
            reset_buffer(dd);
            log_entry("Could not get memory for object list of new device driver");
            return 1;
        }

        /* copy low and high byte of object ID */
        tmp->object_id = value_of(p);

        /* connect the new list entry to the list if this is the first object in the list */
        if(first_object) {
            first_object = 0;
            dd->objects = tmp;
            dd->objects->next = NULL;
            walk = dd->objects;
        }
        else {
            walk->next = tmp;
            walk = walk->next;
            walk->next = NULL;
        }
    }

    return 0;
}

/* query all device drivers if there is already an object with such an ID */
int find_object_ID(uint16_t *oid)
{
    struct device_driver *dd_walk;
    struct object_list *ob_walk;

    /* Find the correct file descriptor in all device drivers */
    for(dd_walk = device_list; dd_walk != NULL; dd_walk = dd_walk->next) {
        /* search in all objects of the device driver */
        for(ob_walk = dd_walk->objects; ob_walk != NULL; ob_walk = ob_walk->next) {
            /* if there is an object with such an ID then return immediatelly */
            if(ob_walk->object_id == *oid)
                return 1;
        }
    }

    return 0;
}

/* parse all read buffers of the connected device drivers for a valid telegram */
int check_read_buffers(void)
{
    struct device_driver *walk;
    int again = 0;

    /* parse read buffers of all devices */
    for(walk = device_list; walk != NULL; walk = walk->next) {
        /* parse read buffer of this device until all bytes are processed */
        do {
            again = 0;
            switch(walk->state) {
                case MCIP_STATE_EMPTY: {
                    if(walk->read_buffer != NULL) {
                        walk->read_buffer_work = walk->read_buffer;
                        walk->state++; /* wait for start byte */
                    }
                    else
                        break;
                }

                case MCIP_STATE_START: {
                    /* check plausiblity */
                    if(walk->read_buffer_work != walk->read_buffer || *(walk->read_buffer_work) != MCIP_START_BYTE) {
                        reset_buffer(walk);
                        break;
                    }

                    walk->read_buffer_work += MCIP_SIZEOF_STARTBYTE; /* set pointer to the first command byte */
                    walk->state++; /* wait for command */
                }

                case MCIP_STATE_COMMAND: {
                    /* check plausiblity */
                    if(walk->read_buffer_work != (walk->read_buffer + MCIP_SIZEOF_STARTBYTE)) {
                        reset_buffer(walk);
                        break;
                    }

                    /* check if both bytes of the command are here */
                    if(!((walk->read_buffer_end - walk->read_buffer_work) >= MCIP_SIZEOF_COMMAND))
                        break;

                    /* command is here */
                    walk->read_buffer_work += MCIP_SIZEOF_COMMAND; /* set pointer to the first length byte */
                    walk->state++; /* wait for length */
                }

                case MCIP_STATE_LENGTH: {
                    /* check plausiblity */
                    if(walk->read_buffer_work != (walk->read_buffer + MCIP_SIZEOF_STARTBYTE + MCIP_SIZEOF_COMMAND)) {
                        reset_buffer(walk);
                        break;
                    }

                    /* check if both bytes of the length are here */
                    if(!((walk->read_buffer_end - walk->read_buffer_work) >= MCIP_SIZEOF_LENGTH))
                        break;

                    /* length is here */

                    /* check if length is too big */
                    if(value_of(walk->read_buffer_work) >= (MCIP_MAX_READ_BUFFER - 7)) {
                        reset_buffer(walk);
                        break;
                    }

                    /* set pointer to the next field (depending on value of length) */
                    walk->read_buffer_work += MCIP_SIZEOF_LENGTH;

                    /* if length is zero, there is no object. Jump directly to checksum */
                    if(value_of(walk->read_buffer + MCIP_OFFSET_LENGTH) == 0)
                        walk->state = MCIP_STATE_CHECKSUM;
                    else
                        walk->state++; /* wait for Object ID */
                }

                case MCIP_STATE_PAYLOAD: {
                    /* check if all bytes of the payload are here */
                    if((walk->read_buffer_end - walk->read_buffer) < (value_of(walk->read_buffer + MCIP_OFFSET_LENGTH) + MCIP_SIZEOF_HEADER))
                        break;

                    /* set pointer to the first checksum byte */
                    walk->read_buffer_work += value_of(walk->read_buffer + MCIP_OFFSET_LENGTH);

                    walk->state++;
                }

                case MCIP_STATE_COMPLETE: {
                    /* process the content of telegram */
                    if (process_telegram(walk) != 0) {
                        /* there was "bye" telgram, remove the device */
                        remove_device(walk);

                        /* do not continue with any devices, because a device has been removed from the chain */
                        return 0;
                    }
                    else {
                        /* care about the rest of the buffer, if there is any */
                        reset_buffer(walk);
                        again = 1;
                    }
                    break;
                }

                default: {
                    break;
                }
            }
        }
        while (again); /* end reading buffer of this particular device */
    } /* end reading buffers of last device */

    return 0;
}

/* parse all write buffers of the connected device drivers for data to be sent */
int check_write_buffers(void)
{
    struct device_driver *walk;

    for(walk = device_list; walk != NULL; walk = walk->next) {
        /* write buffer is empty, when pointers point to the same address */
        if(walk->write_buffer == walk->write_buffer_end)
            continue;

        // Todo: Maybe there should be a dedicated write timer: Wait for its timeout before sending data again?
    }

    return 0;
}

/* process the content of telegram */
int process_telegram(struct device_driver *dd)
{
    switch(value_of(dd->read_buffer + MCIP_OFFSET_COMMAND)) {
        /* these commands are always allowed for both public and private OIDs */
        case MCIP_CMD_HELLO:
            learn_capabilities(dd);
            break;

        case MCIP_CMD_BYE:
            return -1;

        case MCIP_CMD_LOGIN:
            /* Todo */
            break;

        case MCIP_CMD_LOGOUT:
            /* Todo */
            break;

        case MCIP_CMD_ALIVE:
            if(value_of(dd->read_buffer + MCIP_OFFSET_HEADER) == 0) {
                /* modify content of telegram: exchange command alive with ACK, and exchange OIDs */
                *(dd->read_buffer + MCIP_OFFSET_COMMAND)       = MCIP_CMD_ACK;
                *(dd->read_buffer + MCIP_OFFSET_HEADER)        = *(dd->read_buffer + MCIP_OFFSET_OBJECT_ID);
                *(dd->read_buffer + MCIP_OFFSET_HEADER + 1)    = *(dd->read_buffer + MCIP_OFFSET_OBJECT_ID + 1);
                *(dd->read_buffer + MCIP_OFFSET_OBJECT_ID)     = 0;
                *(dd->read_buffer + MCIP_OFFSET_OBJECT_ID + 1) = 0;

                /* send the telegram to its destination */
                return send_telegram(dd);
            }

        /* these commands are only allowed private OIDs */
        case MCIP_CMD_ACK:
        case MCIP_CMD_NACK:
        case MCIP_CMD_READ:
        case MCIP_CMD_READ_WITH_ACK:
        case MCIP_CMD_WRITE:
        case MCIP_CMD_WRITE_WITH_ACK:
        default:
            /* only send it, if its target OID is high enough to be allowed */
            if(!(dd->flag_only_public && (value_of(dd->read_buffer + MCIP_OFFSET_HEADER) <= MCIP_PUBLIC_OIDS)))
                return send_telegram(dd);

            break;
    }

    return 0;
}

/* send a telegram to a device driver */
int send_telegram(struct device_driver *dd)
{
    struct device_driver *dd_walk, *dd_tmp;
    struct object_list *ob_walk;
    int i = 0;
    int read_buffer_size = 0;
    int new_write_buffer_size = 0;
    int old_write_buffer_size = 0;

    /* calculate amount of bytes in read buffer which can be sent */
    read_buffer_size = dd->read_buffer_work - dd->read_buffer;
    /* calculate amount of bytes of remaining bytes in write buffer */
    old_write_buffer_size = dd->write_buffer_end - dd->write_buffer;

    /* do not send a telegram, if the target object ID is unknown */
    if(read_buffer_size < (MCIP_SIZEOF_HEADER + MCIP_SIZEOF_OBJECT_ID))
        return 1;

    /* Find the correct file descriptor in all device drivers */
    for(dd_walk = device_list; dd_walk != NULL; ) {
        /* search in all objects of the device driver */
        for(ob_walk = dd_walk->objects; ob_walk != NULL; ob_walk = ob_walk->next) {
            /* search until a device driver has such an object ID which is in telegram */
            if(ob_walk->object_id == value_of(dd->read_buffer + MCIP_SIZEOF_HEADER)) {
                /* write as much as possible: start from beginning of buffer until working pointer */
                i = send(dd_walk->fd, dd->read_buffer, read_buffer_size, MSG_NOSIGNAL | MSG_DONTWAIT);
                /* writing failed */
                if(i < 0) {
                    log_entry("Unable to write to device (fd %d) %s", dd_walk->fd, strerror(errno));
                    dd_tmp = dd_walk;
                    remove_device(dd_tmp);
                    return -1;
                }
                /* not all data could be written, store the rest in the write buffer */
                else if(i < read_buffer_size) {
                    new_write_buffer_size = read_buffer_size - i;
// Todo: What should we do, if remaining buffer is less than data that should be stored in buffer?
                    /* write buffer is empty */
                    if(dd->write_buffer_end == dd->write_buffer) {
                        dd->write_buffer = malloc(new_write_buffer_size);
                        dd->write_buffer_end = dd->write_buffer + i;
                    }
                    /* there is already data in the write buffer, append new data */
                    else {
                        dd->write_buffer = realloc(dd->write_buffer, old_write_buffer_size + new_write_buffer_size);
                        dd->write_buffer_end = dd->write_buffer + old_write_buffer_size + new_write_buffer_size;
                    }
                }
            }
        }
        if(dd_walk == NULL)
            break;
        dd_walk = dd_walk->next;
    }

    return 0;
}

/* recursively remove all tcp devices
 * this has to be done recursively to avoid a race condition
 * or confusion within the for loop, if a device was removed
 */
int remove_tcp_devices(void)
{
    struct device_driver *walk;

    for(walk = device_list; walk != NULL; walk = walk->next) {
        /* if the file type is TCP, remove the device */
        if(walk->device_type == MCIP_DEVICE_TCP) {
            /* if the remove of the device fails, return */
            if(remove_device(walk))
                return 1;
            /* otherwise call the function again, to search for the next tcp device */
            if(remove_tcp_devices())
                return 1;
            break;
        }
    }

    return 0;
}
