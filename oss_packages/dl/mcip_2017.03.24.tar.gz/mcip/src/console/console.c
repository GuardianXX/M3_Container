/*
 *  MCIP -- Management and Control Information Protocol
 *
 *  Copyright (C) 2012 INSYS Microelectronics GmbH <support@insys-tec.de>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License version 2
 *  as published by the Free Software Foundation.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (see the file COPYING included with this
 *  distribution); if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/* console for MCIP:
   You can send and receive telegrams.
   This is intended to be a debug tool */

#include "../../include/mcip.h"

#define PROTO_NONE      0
#define PROTO_UDS       1
#define PROTO_TCP       2
#define DEFAULT_UDS     "/var/run/mcip.socket"

void usage(void) {
    printf("\nUsage: console <-oid OBJECT_ID> <-proto PROTOCOL> <-dest DESTINATION> [-port PORT]\n");
    printf("    with OBJECT_ID as the OID this program should introduce itself to MCIP\n");
    printf("    with PROTOCOL is \"tcp\" or \"uds\" (default is uds)\n");
    printf("    with PORT as destination Port in case of TCP (default is 4424)\n");
    printf("    with DESTIANTION is IP address or domainname in case of protocol TCP or\n");
    printf("      file path in case of UDS (default is "DEFAULT_UDS")\n\n");
    printf(" Enter the telegram in hex. Spaces are ignored. Send it with new line or line feed. Example:\n");
    printf("  Send write command (hex 8) with payload length 7 (hex 7)\n");
    printf("  to OID \"34\" (hex 22) and payload \"Hello\" (hex 48656c6c6f):\n");
    printf("      55 0800 0700 2200 48656c6c6f\n\n");
    exit(1);
}

int main(int argc, char *argv[])
{
    int m = 0, k = 0, i = 0, sock = -1, x = 0, sel, argn = 1, oid = 0;
    int proto = PROTO_UDS;
    uint8_t p[1500];
    char s[1500], s2[1500];
    char *destination = NULL, *port, default_port[6];
    char default_dest[] = DEFAULT_UDS;
    fd_set fds_master, fds_tmp;
    struct sockaddr_un server;
    struct timeval tv;

    sprintf(default_port, "%d", MCIP_TCP_PORT);
    port = default_port;

    while(argn < argc && argv[argn][0] == '-' ) {
        if(strcmp(argv[argn], "-oid" ) == 0 && argn + 1 < argc) {
            ++argn;
            oid = (unsigned short) atoi(argv[argn]);
        }
        else if(strcmp(argv[argn], "-port" ) == 0 && argn + 1 < argc) {
            ++argn;
            port = argv[argn];
        }
        else if(strcmp( argv[argn], "-dest" ) == 0 && argn + 1 < argc ) {
            ++argn;
            destination = argv[argn];
        }
        else if(strcmp(argv[argn], "-proto" ) == 0 && argn + 1 < argc) {
            ++argn;
            if(strncmp(argv[argn], "uds", 3) == 0)
                proto = PROTO_UDS;
            else if(strncmp(argv[argn], "tcp", 3) == 0)
                proto = PROTO_TCP;
            else
                proto = PROTO_NONE;
        }
        else
            usage();

        ++argn;
    }

    if(argn != argc)
        usage();

    if(oid < 1 || oid > 65534) {
        printf("OID must be greater than 1 and lower than 65535\n");
        usage();
    }

    if(atoi(port) < 1 || atoi(port) > 65534) {
        printf("-port must be greater than 1 and lower than 65535\n");
        usage();
    }

    if(proto == PROTO_NONE) {
        printf("-proto must be \"tcp\" or \"uds\"");
        usage();
    }

    if(destination == NULL) {
        if(proto == PROTO_UDS)
            destination = default_dest;
        else {
            printf("-dest must be defined");
            usage();
        }
    }

    /* prepare packet to say "hello" to mcip */
    s[0] = MCIP_START_BYTE;

    s[1] = MCIP_CMD_HELLO; /* low byte of command */
    s[2] = 0x0;     /* high byte of command */

    s[3] = 0x4; /* low byte of length */
    s[4] = 0x0; /* high byte of length */

    /* Object ID is the local MCIP for the command "hello" */
    s[5] = 0x0; /* low byte of object ID */
    s[6] = 0x0; /* high byte of object ID */

    /* tell MCIP Object ID of this device driver */
    s[7] = (oid & 0xff); /* low byte of object ID */
    s[8] = (oid >> 8) & 0xff; /* high byte of object ID */

    /* establish connection to MCIP */
    if(proto == PROTO_UDS) {
        /* open Unix Domain Socket */
        sock = socket(AF_UNIX, SOCK_STREAM, 0);
        if(sock < 0) {
            printf("Error connecting stream socket\n");
            return 1;
        }

        server.sun_family = AF_UNIX;
        strcpy(server.sun_path, destination);

        if(connect(sock, (struct sockaddr *) &server, sizeof(struct sockaddr_un)) < 0) {
            close(sock);
            printf("Error opening Unix Domain Socket with file %s\n", destination);
            return 1;
        }
    }
    else if(proto == PROTO_TCP) {
        /* open TCP socket */
        struct addrinfo *walk;
        struct addrinfo *res;
        struct addrinfo hints;

        memset(&hints, 0, sizeof(struct addrinfo));
        hints.ai_family = PF_UNSPEC;
        hints.ai_socktype = SOCK_STREAM;

        if(getaddrinfo(destination, port, &hints, &res) != 0) {
            printf("Error getting address info\n");
            return 1;
        }

        for(walk = res; walk != NULL; walk = walk->ai_next) {
            sock = socket(walk->ai_family, walk->ai_socktype, walk->ai_protocol);
            if(sock < 0)
                continue;

            if(connect(sock, walk->ai_addr, walk->ai_addrlen) < 0) {
                close(sock);
                sock = -1;
                continue;
            }
            break;
        }

        freeaddrinfo(res);

        if(sock == -1) {
            printf("Error connecting to MCIP\n");
            return 1;
        }
    }

    /* send hello packet to MCIP */
    if(send(sock, s, 9, MSG_NOSIGNAL) < 0) {
        printf("Error! Could not introduce myself to MCIP\n");
        return -1;
    }

    FD_ZERO(&fds_master);
    FD_SET(sock, &fds_master);
    FD_SET(fileno(stdin), &fds_master);

    for(;;) {
        FD_ZERO(&fds_tmp);
        fds_tmp = fds_master;
        tv.tv_sec = 0;
        tv.tv_usec = 10000;
        sel = select(sock + 1, &fds_tmp, NULL, NULL, &tv);
        if(sel > 0) {
            /* read everything from socket */
            if(FD_ISSET(sock, &fds_tmp)) {
                printf("try to read from socket\n");
                x = read(sock, p, 1500);
                printf("Nr. of RX Data: %d\n", x);
                if(x > 0) {
                    printf("Read: ");
                    for(i = 0; i < x; i++)
                        printf("0x%02x ", p[i]);
                    printf("\n");
                }
                else if(x == -1) {
                    if(errno == EAGAIN || errno == EWOULDBLOCK)
                        sleep(1);
                    else
                        exit(1);
                }
            }

            /* read from stdin */
            memset(s, 0, 1500);
            memset(s2, 0, 1500);
            if(FD_ISSET(fileno(stdin), &fds_tmp)) {
                if(fgets(s, 1500, stdin)) {
                    x = strlen(s);
                    for(i = 0; i < x; i++) {
                        if(s[i] == 0xa || s[i] == 0xd) {
                            s[i] = '\0';
                            break;
                        }
                    }
                    /* remove invalid characters from string */
                    for(m = 0, k = 0; k < i; k++) {
                        if(s[k] >= '0' && s[k] <= '9') {
                            s2[m] = s[k] - 0x30;
                            m++;
                        }
                        else if(s[k] >= 'a' && s[k] <= 'f') {
                            s2[m] = s[k] - 0x57;
                            m++;
                        }
                        else if(s[k] >= 'A' && s[k] <= 'F') {
                            s2[m] = s[k] - 0x37;
                            m++;
                        }
                    }

                    for(m = 0, k = 0; k < i; k += 2, m++)
                        s[m] = s2[k] * 16 + s2[k + 1];

                    if(send(sock, s, x - 1, MSG_NOSIGNAL) < 0)
                        printf("Error writing on socket\n");
                }
            }
        }
    }

    close(sock);

    return 0;
}

