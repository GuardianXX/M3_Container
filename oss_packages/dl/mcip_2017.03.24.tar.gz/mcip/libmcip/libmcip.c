/*
 *  MCIP -- Management and Control Information Protocol
 *
 *  Copyright (C) 2012 INSYS Microelectronics GmbH <support@insys-tec.de>
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

/* collection of functions, that may ease coding MCIP clients */

#include "../include/libmcip.h"
#include "../include/mcip.h"

/* this function opens the AF_UNIX socket specified by socket_file */
int mcip_open_uds_socket(char *socket_file)
{
    int n, error = 0;
    int sockfd;
    socklen_t len;
    fd_set rset,wset;
    struct timeval tval;
    struct sockaddr_un un;

    if(socket_file == NULL)
        return -1;

    len = sizeof(un);
    sockfd = socket(AF_UNIX, SOCK_STREAM, 0);
    if(sockfd < 0)
        return -1;

    memset(&un, 0, sizeof(un));
    un.sun_family = AF_UNIX;
    strncpy(un.sun_path, socket_file, strlen(socket_file));
    len = sizeof(un);

    /* get socket flags and set it to non blocking */
    if(fcntl(sockfd, F_SETFL, fcntl(sockfd, F_GETFL, 0) | O_NONBLOCK) < 0)
        return -1;

    /* don't let future subprocesses inherit child socket */
    if(fcntl(sockfd, F_SETFD, FD_CLOEXEC) < 0)
        return -1;

    if((n = connect(sockfd, (struct sockaddr *)&un, len)) < 0)
        if(errno != EINPROGRESS)
            return -1;

    /* connect worked at once */
    if(n == 0)
        return sockfd;

    /* connect has not returned yet */
    FD_ZERO(&rset);
    FD_SET(sockfd, &rset);
    wset = rset;
    tval.tv_sec = 1;
    tval.tv_usec = 0;

    if((n = select(sockfd + 1, &rset, &wset, NULL, &tval)) == 0) {
        /* connect timed out */
        close(sockfd);
        return -1;
    }

    /* try connect once again to check again; if remote side sent a TCP
       RST the former connect is not working */
    if(connect(sockfd, (struct sockaddr *)&un, len) < 0)
        if(errno != EISCONN)
            return -1;

    /* connect finaly made it, check if it is usable */
    if(FD_ISSET(sockfd, &rset) || FD_ISSET(sockfd, &wset)) {
        len = sizeof(error);
        if(getsockopt(sockfd, SOL_SOCKET, SO_ERROR, &error, &len) < 0) {
            /* getsockopt failed */
            close(sockfd);
            return -1;
        }
    }

    return sockfd;
}

/* this function connects to remote mcip server  */
int mcip_open_tcp_socket(struct sockaddr_in *remote_mcip_server)
{

    int sockfd = -1;
    int flags = 0, error = 0;
    socklen_t len = 0;
    fd_set rset,wset;
    struct timeval tval;

    if (NULL == remote_mcip_server) {
        return -1;
    }

    len = sizeof(struct sockaddr_in);
    sockfd = socket(remote_mcip_server->sin_family, SOCK_STREAM, 0);

    if (0 > sockfd) {
        return -1;
    }

    /* try a non blocking connect */
    flags = fcntl(sockfd, F_GETFL, 0);

    if (0 > fcntl(sockfd, F_SETFL, flags | O_NONBLOCK)) {
        return -1;
    }

    /* don't let future subprocesses inherit child socket */
    if (0 > fcntl(sockfd, F_SETFD, FD_CLOEXEC)) {
        return -1;
    }

    /* try to connect */
    if (0 == connect(sockfd, (struct sockaddr *) remote_mcip_server, len)) {
        /* connect worked */
        return sockfd;
    } else {
        if (EINPROGRESS != errno) {
            return -1;
        } /* else try again -> connect still in progress (non blocking connect) */
    }

    /* connect has not returned yet wait a second */
    FD_ZERO(&rset);
    FD_SET(sockfd, &rset);
    wset = rset;
    tval.tv_sec = 1;
    tval.tv_usec = 0;

    if (0 == select(sockfd + 1, &rset, &wset, NULL, &tval)) {
        /* connect timed out */
        close(sockfd);
        return -1;
    }

    /* try connect once again to check again; if remote side sent a TCP
       RST the former connect is not working */
    if(0 > connect(sockfd, (struct sockaddr *) remote_mcip_server, len)) {
        if(EISCONN != errno) {
           return -1;
        }
    }

    /* connect finaly made it, check if it is usable */
    if (FD_ISSET(sockfd, &rset) || FD_ISSET(sockfd, &wset)) {
        len = sizeof(error);
        if (getsockopt(sockfd, SOL_SOCKET, SO_ERROR, &error, &len) < 0) {
            /* getsockopt failed */
            close(sockfd);
            return -1;
        }
    }

    return sockfd;

}

/* close file descriptor and set value to -1 */
void mcip_close_fd(int *fd)
{
    if(fd == NULL)
        return;

    if(*fd != -1) {
        close(*fd);
        *fd = -1;
    }
    return;
}

/* append oid struct at end of list */
int mcip_oid_append(struct oid_list **ptr, uint16_t oid)
{
    while(*ptr != NULL) /* goto last element */
        ptr = &(*ptr)->next;
    *ptr = malloc(sizeof **ptr);
    if(*ptr == NULL)
        return -1;

    (*ptr)->next = NULL;
    (*ptr)->oid = oid;
    return 0;
}

/*  destroy complete oid list */
void mcip_oids_destroy(struct oid_list *head)
{
    struct oid_list *tmp;

    while(head != NULL) {
        tmp = head->next;
        free(head);
        head = tmp;
    }
    return;
}

/* connect to MCIP via unix domains socket and register object ids */
int mcip_uds_register(char *uds_socket, struct oid_list *my_oids)
{
    int fd;

    if(my_oids == NULL || uds_socket == NULL)
        return -1;

    fd = mcip_open_uds_socket(uds_socket);
    if(fd < 0) {
        return -1;
    }
    if(mcip_send_hello(fd, my_oids) < 0) {
        return -1;
    }

    return fd;
}

/* say bye to MCIP and close the socket and set file descriptor to -1 */
int mcip_uds_deregister(int *fd)
{
    char s[5];

    if(fd == NULL || *fd == -1)
        return -1;

    memset(s, 0x00, sizeof(s));
    s[0] = MCIP_START_BYTE;
    s[1] = MCIP_CMD_BYE;
    /* length is zero */

    if(send(*fd, s, 5, MSG_NOSIGNAL) < 0) {
        mcip_close_fd(fd);
        return -1;
    }

    mcip_close_fd(fd);
    return 0;
}

/* connect to MCIP via tcp to remote mcip server and register object ids */
int mcip_tcp_register(struct sockaddr_in *remote_mcip_server, struct oid_list *my_oids)
{
    int tcp_fd = -1;

    if ( NULL == my_oids || NULL == remote_mcip_server) {
        return -1;
    }

    tcp_fd = mcip_open_tcp_socket(remote_mcip_server);

    if (0 > tcp_fd) {
        return -1;
    }

    if (0 > mcip_send_hello(tcp_fd, my_oids)) {
        return -1;
    }

    return tcp_fd;

}

/* say bye to MCIP and close the socket and set file descriptor to -1 */
int mcip_tcp_deregister(int *fd)
{
    return mcip_uds_deregister(fd);
}

/* send mcip hello to mcip daemon; return -1 in case of failure */
int mcip_send_hello(int fd, struct oid_list *head)
{
    int i = 0, ret;
    uint8_t *payload, *hlp_ptr;
    struct oid_list *tmp, *work;

    work = head;
    while(head != NULL) {
        tmp = head->next;
        head = tmp;
        i++; /* count oids */
    }
    if (i == 0)
        return -1; /* no oid */

    payload = malloc(MCIP_SIZEOF_OBJECT_ID + (i << 1));
    if(payload == NULL)
        return -1;
    hlp_ptr = payload;

    /* destination OID is MCIP_DAEMON_OID */
    *payload++ = (uint8_t)(MCIP_DAEMON_OID & 0x00ff);
    *payload++ = (uint8_t)((MCIP_DAEMON_OID & 0xff00) >> 8);

    while(work != NULL) {
        *payload++ = (uint8_t)(work->oid & 0x00ff);
        *payload++ = (uint8_t)((work->oid & 0xff00) >> 8);
        tmp = work->next;
        work = tmp;
    }

    ret = mcip_send(fd, MCIP_CMD_HELLO, MCIP_SIZEOF_OBJECT_ID + (i << 1), hlp_ptr);
    free(hlp_ptr);
    return ret;
}

/* send generic MCIP telegram */
int mcip_send(int sock, uint16_t cmd, uint16_t length, void* payload)
{
    uint8_t *payload_content = (uint8_t*) payload;
    uint8_t *s = NULL;

    if(payload_content == NULL)
        return -1;

    s = malloc(5 + length);

    /* prepare header of telegram */
    s[0] = MCIP_START_BYTE;
    s[1] = cmd & 0xff; /* low byte of command */
    s[2] = (cmd & 0xff00) >> 8; /* high byte of command */
    s[3] = length & 0xff; /* low byte of length */
    s[4] = (length & 0xff00) >> 8; /* high byte of length */

    /* append payload to header */
    memcpy(s + 5, payload_content, length);

    /* send header and payload */
    if(send(sock, s, 5 + length, MSG_NOSIGNAL) < 0) {
        free(s);
        return -1;
    }

    free(s);

    return 0;
}

/* read data from MCIP interface until a valid telegram is in the buffer */
int mcip_read_data(int sock, void **mcip_buf, void **p_mcip_buf)
{
    int read_bytes = 0;
    int old_buffer_size = 0;
    uint8_t *tmp_buffer = NULL;
    uint8_t **mcip_buf_start = (uint8_t**) mcip_buf;
    uint8_t **mcip_buf_end   = (uint8_t**) p_mcip_buf;

    /* buffer is empty, create a small one */
    if((*mcip_buf_end == NULL) || (*mcip_buf_start == NULL)) {
        tmp_buffer = malloc(MCIP_READ_BUFFER);
        read_bytes = read(sock, tmp_buffer, MCIP_READ_BUFFER);
        if(read_bytes == 0) {
            free(tmp_buffer);
            return -1;
        }
        else if(read_bytes == -1) {
            free(tmp_buffer);
            if (errno == EAGAIN || errno == EWOULDBLOCK)
                return 0;
            else
                return -1;
        }

        *mcip_buf_start = realloc(tmp_buffer, read_bytes);
        *mcip_buf_end   = *mcip_buf_start + read_bytes;
    }
    else {
        /* there is already data in the buffer, append new data */
        old_buffer_size = *mcip_buf_end - *mcip_buf_start;

        /* there is obviously too much data */
        if(old_buffer_size >= MCIP_MAX_READ_BUFFER)
            return -1;

        tmp_buffer = malloc(MCIP_MAX_READ_BUFFER);
        read_bytes = read(sock, tmp_buffer, MCIP_MAX_READ_BUFFER);
        if(read_bytes == 0) {
            free(tmp_buffer);
            return -1;
        }
        else if(read_bytes == -1) {
            free(tmp_buffer);
            if (errno == EAGAIN || errno == EWOULDBLOCK)
                return 0;
            else
                return -1;
        }

        /* append new data */
        *mcip_buf_start = realloc(*mcip_buf_start, old_buffer_size + read_bytes);
        memcpy(*mcip_buf_start + old_buffer_size, tmp_buffer, read_bytes);
        *mcip_buf_end = *mcip_buf_start + old_buffer_size + read_bytes;

        free(tmp_buffer);
    }

    /* check if the telegram has a minimum size (start byte, command, length, OID */
    if((*mcip_buf_end - *mcip_buf_start) < 7)
        return 0;
    else
        return 1;
}

/* cut leading bytes in mcip buffer */
int mcip_remove_telegram(void **mcip_buf, void **p_mcip_buf, uint8_t searchfor)
{
    ptrdiff_t offset = 0;
    uint8_t **mcip_buf_start = (uint8_t**) mcip_buf;
    uint8_t **mcip_buf_end   = (uint8_t**) p_mcip_buf;
    uint8_t *p = NULL, *tmp_buffer;

    if(*mcip_buf_start == NULL || *mcip_buf_end == NULL)
        return -1;

    if(searchfor == SEARCH_NEXT_TELEGRAM)
        p = *mcip_buf_start + MCIP_SIZEOF_HEADER + ((*mcip_buf_start)[3] & 0xFF) + (((*mcip_buf_start)[4] << 8) & 0xFF00);
    else if(searchfor == SEARCH_NEXT_STARTBYTE)
        p = *mcip_buf_start + 1;
    else
        return -1;

    /* cut everything until the next start byte */
    for(; ;) {
        if(p == *mcip_buf_end || *p == MCIP_START_BYTE)
            break;
        else
            p++;
    }

    offset = *mcip_buf_end - p;

    /* resize buffer and set pointers to new addresses */
    if(offset > 0) {
        tmp_buffer = malloc(offset);
        memcpy(tmp_buffer, p, offset);
        free(*mcip_buf_start);
        *mcip_buf_start = tmp_buffer;
        *mcip_buf_end = *mcip_buf_start + offset;
        return 1;
    }
    else {
        free(*mcip_buf_start);
        *mcip_buf_start = *mcip_buf_end = NULL;
        return 0;
    }

    return -1;
}
