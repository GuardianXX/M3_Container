MCIP -- Management and Control Information Protocol
===================================================

MCIP is a lightweight inter-process communication (IPC)
system. This project implements
- a protocol,
- a daemon and
- a shared library.

It is aimed to be as simple, tiny and fast as possible,
so it is adequate for embedded systems.

Read more in ./docs
