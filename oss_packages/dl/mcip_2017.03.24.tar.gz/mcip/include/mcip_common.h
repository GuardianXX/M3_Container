/*
 *  MCIP -- Management and Control Information Protocol
 *
 *  Copyright (C) 2012 INSYS Microelectronics GmbH <support@insys-tec.de>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License version 2
 *  as published by the Free Software Foundation.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (see the file COPYING included with this
 *  distribution); if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef __MCIP_COMMON__
#define __MCIP_COMMON__

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <signal.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <syslog.h>
#include <termios.h>
#include <unistd.h>

#define MCIP_START_BYTE          0x55 /* Start byte indicates beginning of a new telegram */

#define MCIP_MAX_TEXT_LENGTH      300 /* standard length for reading from files */
#define MCIP_READ_BUFFER         4096 /* amount of bytes for a usual read */
#define MCIP_MAX_READ_BUFFER    65535 /* maximum amount of bytes for reading from a device */
#define MCIP_DEFAULT_PORT       26499 /* default port, on with MCIP is listening for other MCIP peers */
#define MCIP_UDS_BACKLOG           10 /* maximum length the UDS listen queue of pending connections may grow to */

/* default file paths */
#define MCIP_DEFAULT_CONF   "/etc/mcip.conf"     /* mcip default configuration file */
#define MCIP_DEFAULT_PID    "/var/run/mcip.pid"  /* write PID file */
#define MCIP_DEFAULT_UDS    "/var/run/mcip.socket" /* MCIP listens on this UDS socket file for drivers to connect */

/* default ports */
#define MCIP_TCP_PORT           4424

/* types of mcip devices */
#define MCIP_DEVICE_UDS     0
#define MCIP_DEVICE_TCP     1

/* states of device driver read buffers */
#define MCIP_STATE_EMPTY         0x00 /* device did not send any data yet */
#define MCIP_STATE_START         0x01 /* device sent at least the start byte of the telegram */
#define MCIP_STATE_COMMAND       0x02 /* device sent the command */
#define MCIP_STATE_LENGTH        0x03 /* device sent the length */
#define MCIP_STATE_PAYLOAD       0x04 /* device sent the payload */
#define MCIP_STATE_CHECKSUM      0x05 /* device sent the checksum */
#define MCIP_STATE_COMPLETE      0x06 /* there is a complete telegram */

/* command defines */
#define MCIP_CMD_NACK            0x00 /* send a NACK and optionally the object "error" as payload */
#define MCIP_CMD_ACK             0x01 /* send ACK */
#define MCIP_CMD_HELLO           0x02 /* device driver informs MCIP about its objects */
#define MCIP_CMD_BYE             0x03 /* device driver want to disconnect from MCIP */
#define MCIP_CMD_LOGIN           0x04 /* start authentication process */
#define MCIP_CMD_LOGOUT          0x05 /* log out from a session */
#define MCIP_CMD_READ            0x06 /* send read request */
#define MCIP_CMD_READ_WITH_ACK   0x07 /* send read request, ask for a separate confirmation of this request */
#define MCIP_CMD_WRITE           0x08 /* send write request */
#define MCIP_CMD_WRITE_WITH_ACK  0x09 /* send write request, ask for separate confirmation of this request */
#define MCIP_CMD_ALIVE           0x10 /* message from MCIP to driver: Are you still alive? */

/* definition of the MCIP protocol */
#define MCIP_SIZEOF_STARTBYTE    1
#define MCIP_SIZEOF_COMMAND      2
#define MCIP_SIZEOF_LENGTH       2
#define MCIP_SIZEOF_HEADER       5
#define MCIP_SIZEOF_OBJECT_ID    2

#define MCIP_OFFSET_STARTBYTE    0
#define MCIP_OFFSET_COMMAND      1
#define MCIP_OFFSET_LENGTH       3
#define MCIP_OFFSET_HEADER       5
#define MCIP_OFFSET_OBJECT_ID    7

/* MCIP public OIDs are greater than this OID */
#define MCIP_PUBLIC_OIDS         1000

/* MCIP OIDs */
#define MCIP_DAEMON_OID          0

struct mcip_telegram {
    uint8_t *startbyte;    /* 1 byte: this has always to be START_BYTE */
    uint8_t *command;      /* 2 bytes: describes the intention of this telegram */
    uint8_t *length;       /* 2 bytes: sum of bytes of object ID and object value */
    uint8_t *object_id;    /* 2 bytes: unique ID of object */
    uint8_t *object_value; /* 1 byte: payload buffer, which contains actual payload */
};

#endif
