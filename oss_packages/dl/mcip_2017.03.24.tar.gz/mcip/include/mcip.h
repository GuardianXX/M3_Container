/*
 *  MCIP -- Management and Control Information Protocol
 *
 *  Copyright (C) 2012 INSYS Microelectronics GmbH <support@insys-tec.de>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License version 2
 *  as published by the Free Software Foundation.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (see the file COPYING included with this
 *  distribution); if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef __MCIP__
#define __MCIP__

#include "mcip_common.h"

/* declaration of objects, that a device driver is capable of */
struct object_list {
    uint16_t object_id;       /* unique ID of object */
    struct object_list *next; /* pointer to the next object */
};

/* declaration of a device driver */
struct device_driver {
    int fd;                     /* file descriptor to communicate with */
    char device_type;           /* connection type of this device (tcp, uds) */
    char flag_only_public;      /* if set, only packets to target OIDs greater MCIP_PUBLIC_OIDs are forwarded */
    char state;                 /* byte for state machine */
    uint8_t *write_buffer;      /* pointer to start of write buffer */
    uint8_t *write_buffer_end;  /* pointer to last byte of write buffer */
    uint8_t *read_buffer;       /* pointer to start of read buffer */
    uint8_t *read_buffer_end;   /* pointer to last byte of read buffer */
    uint8_t *read_buffer_work;  /* pointer to work within a telegram */
    struct object_list *objects;/* pointer to the objects serviced by this driver */
    struct device_driver *next; /* pointer to the next device driver */
};

extern struct device_driver *device_list; /* pointer to the very first device driver, that is connected to this MCIP */

extern fd_set fds_master;      /* file descriptor set with all file descriptors */
extern fd_set fds_tmp;         /* temporary file descriptor */

extern int fd_max;             /* file descriptor containing maximal fd of all UDS or TCP connections */
extern int fd_uds;             /* file descriptor for listening for new drivers to connect */
extern int fd_tcp;             /* file descriptor for other MCIPs connecting via TCP */

struct mcip_config {
    char *log_file;         /* log file of MCIP */
    char *pid_file;         /* write PID file */
    char *uds_file;         /* MCIP listens on this UDS socket file for drivers to connect */
    char *tcp_bind;         /* MCIP listens on this network interface for drivers to connect */
    int TCP_listen_port;    /* MCIP listens on this port for TCP connections from other MCIPs */
    char fork_to_daemon;    /* MCIP should start as daemon (1) or stay in foreground (0) */
};

extern int reread_config_flag; /* flag, to notice main loop from occurance of SIGUSR1 */
extern int sigterm_flag;       /* flag, to notice main loop from occurance of SIGTERM and SIGINT */

extern struct mcip_config config;

/* in mcip.c */
void sigpipe_handler(int sig);
int check_read_buffers(void);
int check_write_buffers(void);
int process_telegram(struct device_driver *dd);
int send_telegram(struct device_driver *dd);

/* in util.c */
void log_entry(char *text, ...);
int daemonize(void);
void close_fd(int *fd);
void safefree(void **pp);
uint16_t value_of(uint8_t *start_byte);
int already_running(char *pid_file);

/* in config.c */
int check_config(void);
int read_config(char *config_file);
int reread_config(char *config_file);

/* in tcp.c */
int open_TCP_listener(void);
int accept_TCP_socket(void);

/* in device.c */
int open_device_listener(void);
int add_device(void);
int remove_device(struct device_driver *dd);
int read_device(struct device_driver *dd);
int reset_buffer(struct device_driver *dd);
int learn_capabilities(struct device_driver *dd);
int find_object_ID(uint16_t *oid);
int remove_tcp_devices(void);

#endif
