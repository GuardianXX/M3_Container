/*
 *  MCIP -- Management and Control Information Protocol
 *
 *  Copyright (C) 2012 INSYS Microelectronics GmbH <support@insys-tec.de>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License version 2
 *  as published by the Free Software Foundation.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (see the file COPYING included with this
 *  distribution); if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef __LIB_MCIP__
#define __LIB_MCIP__

#include "mcip_common.h"

#define SEARCH_NEXT_TELEGRAM    0x0
#define SEARCH_NEXT_STARTBYTE   0x1

#ifdef __cplusplus
extern "C"
{
#endif

struct oid_list {
    uint16_t oid;
    struct oid_list *next;
};

int mcip_open_uds_socket(char *socket_file);
int mcip_open_tcp_socket(struct sockaddr_in *remote_mcip_server);
int mcip_oid_append(struct oid_list **n, uint16_t oid);
void mcip_oids_destroy(struct oid_list *head);
void mcip_close_fd(int *fd);
int mcip_uds_register(char *uds_socket, struct oid_list *my_oids);
int mcip_tcp_register(struct sockaddr_in *remote_mcip_server, struct oid_list *my_oids);
int mcip_uds_deregister(int *fd);
int mcip_tcp_deregister(int *fd);
int mcip_read_data(int sock, void **mcip_buf, void **p_mcip_buf);
int mcip_remove_telegram(void **mcip_buf, void **p_mcip_buf, uint8_t searchfor);
int mcip_send_hello(int fd, struct oid_list *own_object_ids);
int mcip_send(int sock, uint16_t cmd, uint16_t length, void *payload);
int mcip_send_bye(int sock);

#ifdef __cplusplus
}
#endif

#endif
