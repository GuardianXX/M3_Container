#ifndef VSF_VERSION_H
#define VSF_VERSION_H

#define VSF_VERSION "3.0.3"

#endif /* VSF_VERSION_H */

